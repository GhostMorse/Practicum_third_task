from random_forest import RandomForestMSE
from boosting import GradientBoostingMSE

import time
import pandas as pd
import numpy as np

data = pd.read_csv("kc_house_data.csv")
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split

data_copy = data.copy()
del data_copy["id"], data_copy["date"], data_copy["zipcode"]

X = data_copy[list(set(data_copy.columns) - set(["price"]))]
y = data_copy["price"].apply(np.log) * 100

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.3)

scaler = StandardScaler()
X_scaled_train = scaler.fit_transform(X_train, y_train)
X_scaled_test = scaler.transform(X_test)

y_train = y_train.to_numpy()
y_test = y_test.to_numpy()


grid_dict = {"max_depth": [None, 10,20], "max_features": [1,3,5]}
rmsle_history = []
time_history = []
estimators = []
depths = []
Fdimensions = []
for n_est in [10,20,30]:
  for mx_dpth in grid_dict["max_depth"]:
    for mx_feat in grid_dict["max_features"]:
      RF = RandomForestMSE(n_estimators = n_est, tree_params = {"max_depth": mx_dpth, "max_features": mx_feat})
      start = time.time()
      hist = RF.fit(X = X_scaled_train, y = y_train, X_val = X_scaled_test, y_val = y_test, patience = 2)
      y_pred = RF.predict(X_scaled_test)
      end = time.time() - start
      estimators.append(n_est)
      depths.append(mx_dpth)
      Fdimensions.append(mx_feat)
      rmsle_history.append(hist)
      time_history.append(end)

RanForDATA = pd.DataFrame({"time": time_history, "rmsle_convergence": rmsle_history, "estimators": estimators, "depth": depths, "features_per_leaf": Fdimensions})
RanForDATA.to_csv('RF.csv')


lr_list = [1e-3, 0.01, 0.1]
boosting_rmsle_history = []
boosting_time_history = []
estimators = []
depths = []
Fdimensions = []
learning_rates = []

for n_est in [10,20,30]:
  for mx_dpth in grid_dict["max_depth"]:
    for mx_feat in grid_dict["max_features"]:
      for lr in lr_list:
        GB = GradientBoostingMSE(n_estimators = n_est, tree_params = {"max_depth": mx_dpth, "max_features": mx_feat}, learning_rate = lr)
        start = time.time()
        hist = GB.fit(X = X_scaled_train, y = y_train, X_val = X_scaled_test, y_val = y_test, patience = 2)
        y_pred = GB.predict(X_scaled_test)
        end = time.time() - start
        boosting_rmsle_history.append(hist)
        boosting_time_history.append(end)
        estimators.append(n_est)
        depths.append(mx_dpth)
        Fdimensions.append(mx_feat)
        learning_rates.append(lr)

GBDATA = pd.DataFrame({"time": boosting_time_history, "rmsle_convergence": boosting_rmsle_history, "estimators": estimators, "depth": depths, "features_per_leaf": Fdimensions, "learning_rate": learning_rates})
GBDATA.to_csv('GB.csv')

